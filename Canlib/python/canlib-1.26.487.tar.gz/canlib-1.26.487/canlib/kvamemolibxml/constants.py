XML_ERROR_MESSAGE_LENGTH = 2048

KvaXmlValidationStatusOK = 0
KvaXmlStatusOK = 0

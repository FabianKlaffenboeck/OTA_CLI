kvdOK = 0

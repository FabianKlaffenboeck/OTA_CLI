var searchData=
[
  ['helper_20functions',['Helper functions',['../group___helper.html',1,'']]]
];

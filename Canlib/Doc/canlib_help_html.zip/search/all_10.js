var searchData=
[
  ['quality',['quality',['../kv_diag_8h.html#acac7df77df55f2a1bfd8d8d18340b773',1,'bitrate_t']]]
];

var page_user_guide_kvadblib_samples =
[
    [ "Using CAN databases", "page_example_c_candb.html", null ],
    [ "Send database signal", "page_example_c_gensig.html", null ],
    [ "Create a J1939 db", "page_example_c_j1939db.html", null ]
];
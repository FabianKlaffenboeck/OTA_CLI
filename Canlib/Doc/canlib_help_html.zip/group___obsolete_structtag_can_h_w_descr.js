var group___obsolete_structtag_can_h_w_descr =
[
    [ "cardType", "group___obsolete.html#a359605673676d6f622b7b0e3e7c52982", null ],
    [ "channel", "group___obsolete.html#adf7dff2c57c0da9a4a2b70e3e815be31", null ],
    [ "circuitType", "group___obsolete.html#ab589b62ba66057923f4dac909e0f3e78", null ]
];
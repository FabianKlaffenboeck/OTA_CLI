var group__grp__kvrlib =
[
    [ "Local configuration", "group___configuration.html", "group___configuration" ],
    [ "Network information", "group___network.html", "group___network" ],
    [ "Device Discovery", "group___discovery.html", "group___discovery" ],
    [ "Helper functions", "group___helper.html", "group___helper" ]
];
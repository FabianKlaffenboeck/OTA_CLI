var group__j1587__general =
[
    [ "j1587BusOff", "group__j1587__general.html#ga0dafc22cc3147bf68a3502d643851ace", null ],
    [ "j1587BusOn", "group__j1587__general.html#gaf730fab726c0e5a524af0b843bfef15f", null ],
    [ "j1587Close", "group__j1587__general.html#gab22ee2c5a967c611c0ebf0a2b69d5fb3", null ],
    [ "j1587Configure", "group__j1587__general.html#gab0405005b58c5c1dc30b840c5e50ce75", null ],
    [ "j1587GetCanHandle", "group__j1587__general.html#ga704d965b5965d429405aeca53f79e062", null ],
    [ "j1587GetFirmwareVersion", "group__j1587__general.html#ga6f15d30b607348e2d2638d4d6cbc05d2", null ],
    [ "j1587InitializeLibrary", "group__j1587__general.html#ga05e527ed5611a37875494f18284f3342", null ],
    [ "j1587OpenChannel", "group__j1587__general.html#gaa21714de8be1af79afd7d56d38d4b4fe", null ],
    [ "j1587ReadMessageWait", "group__j1587__general.html#ga4347327b367910f5a777c3f054115f39", null ],
    [ "j1587ReadTimer", "group__j1587__general.html#gae9d6fdd6b254c2e9a3d28deebb256518", null ],
    [ "j1587SetBitrate", "group__j1587__general.html#ga5d56ee062e2c8461d45e55d1b93b7215", null ],
    [ "j1587WriteMessageWait", "group__j1587__general.html#ga69f23061d70b00e6b4913f5170dc10b9", null ],
    [ "j1587WriteSync", "group__j1587__general.html#gad32ad5a4b572941c695d24665065a30d", null ]
];
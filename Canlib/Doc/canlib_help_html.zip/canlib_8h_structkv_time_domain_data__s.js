var canlib_8h_structkv_time_domain_data__s =
[
    [ "nMagiSyncedMembers", "canlib_8h.html#aadd2929832bd903c78ddf59c21feea05", null ],
    [ "nMagiSyncGroups", "canlib_8h.html#ab8dca255d18320cb7bd22b0448d78fb7", null ],
    [ "nNonMagiSyncCards", "canlib_8h.html#af00948e6feb807b210c69fd5945e7068", null ],
    [ "nNonMagiSyncedMembers", "canlib_8h.html#a9cc0826be3a3477969cc862737e0f334", null ]
];
var kv_diag_8h_structkv_diag_sample_8msg =
[
    [ "data", "kv_diag_8h.html#ad86924571a9ec796dff8751832d99c9b", null ],
    [ "dlc", "kv_diag_8h.html#a95e10614fcf9d33c1d95a17cd02d2303", null ],
    [ "flag", "kv_diag_8h.html#a327a6c4304ad5938eaf0efb6cc3e53dc", null ],
    [ "id", "kv_diag_8h.html#ab80bb7740288fda1f201890375a60c8f", null ],
    [ "time", "kv_diag_8h.html#a07cc694b9b3fc636710fa08b6922c42b", null ]
];
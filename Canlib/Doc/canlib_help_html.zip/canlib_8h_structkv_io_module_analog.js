var canlib_8h_structkv_io_module_analog =
[
    [ "AI1", "canlib_8h.html#ad4ea693fe3b31c0d44fdc8d8edad2061", null ],
    [ "AI2", "canlib_8h.html#a09a8103e80a3ca67fe8076b14c02ea98", null ],
    [ "AI3", "canlib_8h.html#a5ee7aea94792b76835890e4537dd725d", null ],
    [ "AI4", "canlib_8h.html#a1fb7a7138a7a7715db157327905f716e", null ],
    [ "AO1", "canlib_8h.html#ac2f16b8dd9623f2e9318673706b96c20", null ],
    [ "AO2", "canlib_8h.html#a9e8939e576ba17b7d2157cb4e006080d", null ],
    [ "AO3", "canlib_8h.html#a5cb667a59dbff8de365b5d9f6a6cf4ec", null ],
    [ "AO4", "canlib_8h.html#a756091c81c808e2591d47c73a653b29e", null ],
    [ "type", "canlib_8h.html#ac765329451135abec74c45e1897abf26", null ]
];
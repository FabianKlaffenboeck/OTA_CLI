var kvrlib_8h_structkvr_device_info =
[
    [ "accessibility", "kvrlib_8h.html#a06e4ba34ce772e68b33e2dd16055f505", null ],
    [ "accessibility_pwd", "kvrlib_8h.html#a70c22651a3079bc5b3815dec2901ec69", null ],
    [ "availability", "kvrlib_8h.html#a719e69527c3b7880e8890441d2f4ef4b", null ],
    [ "base_station_id", "kvrlib_8h.html#a709fbf2d47cdbee24e536fd4579b21fc", null ],
    [ "client_address", "kvrlib_8h.html#a4b5decadfbf8e765903c3863b83fd68d", null ],
    [ "device_address", "kvrlib_8h.html#aa2b8d4e5c35518a9cf58723f8a48153c", null ],
    [ "ean_hi", "kvrlib_8h.html#a6be62add221e1a21cb80dd2650f4d632", null ],
    [ "ean_lo", "kvrlib_8h.html#a29984fc8d4a4a717b81535a445e6be2b", null ],
    [ "encryption_key", "kvrlib_8h.html#aacf1e09148234a9e080ee04d9db9185e", null ],
    [ "fw_build_ver", "kvrlib_8h.html#aad14d5e4342bee55fde0952f75db99d8", null ],
    [ "fw_major_ver", "kvrlib_8h.html#a4338b44a527d2a89fd0b2f8d38a223b9", null ],
    [ "fw_minor_ver", "kvrlib_8h.html#ad0024e0dc299e9e78f3365c3605c1493", null ],
    [ "host_name", "kvrlib_8h.html#af30d16605d5c80183cd199983a653081", null ],
    [ "name", "kvrlib_8h.html#a8e03167ce04350be901b028cc4cf1ce1", null ],
    [ "request_connection", "kvrlib_8h.html#a2d0ed331650715b2758668e03c6ecd2c", null ],
    [ "reserved1", "kvrlib_8h.html#ae67e2c0ec4e8c9e9504a0f38e7415084", null ],
    [ "reserved2", "kvrlib_8h.html#a42a59db44a2f07b7fcbe7c4de3f7cba7", null ],
    [ "ser_no", "kvrlib_8h.html#a5ec0993bdcba47c3350e42b1f9c1b720", null ],
    [ "struct_size", "kvrlib_8h.html#a918008f072eabe22292c01d3e48dece3", null ],
    [ "usage", "kvrlib_8h.html#a5d7b59852b350ed10c69d80f25a15c37", null ]
];
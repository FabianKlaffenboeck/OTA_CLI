var kv_diag_8h_structbitrates__t =
[
    [ "bitrate", "kv_diag_8h.html#a9b69ac1d9a035cf32487c02eb1e90368", null ],
    [ "bitrate_brs", "kv_diag_8h.html#a52ce335bfc68ea72b4b213625c875981", null ]
];
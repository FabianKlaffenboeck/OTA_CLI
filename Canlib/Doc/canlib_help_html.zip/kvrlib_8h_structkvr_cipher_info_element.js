var kvrlib_8h_structkvr_cipher_info_element =
[
    [ "capability", "kvrlib_8h.html#ae44a58b4520a788452773ea854fa0959", null ],
    [ "group_cipher", "kvrlib_8h.html#a6a0fa87a34d3002eb96c2aca9c79b0a8", null ],
    [ "list_cipher_auth", "kvrlib_8h.html#a25cdd6f20aed172960a8da81bff34a9a", null ],
    [ "version", "kvrlib_8h.html#acd99bb05ca015e7d74448acb1deba7ca", null ]
];
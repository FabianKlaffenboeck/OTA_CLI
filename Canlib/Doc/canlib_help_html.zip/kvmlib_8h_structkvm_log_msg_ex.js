var kvmlib_8h_structkvm_log_msg_ex =
[
    [ "channel", "kvmlib_8h.html#aeec5b590ec61f511a514428c6cb22937", null ],
    [ "data", "kvmlib_8h.html#a62823cfc5356727ed036cea88e873777", null ],
    [ "dlc", "kvmlib_8h.html#a7d3cf80248d9011329b4b269f8b7d2c4", null ],
    [ "flags", "kvmlib_8h.html#a81a27ce50e78368b0d0de1e8767fd32d", null ],
    [ "id", "kvmlib_8h.html#a3384d9640634d49e84776a97f3e2c241", null ],
    [ "timeStamp", "kvmlib_8h.html#aa1fa735b38f32cc201831ea72527ec37", null ]
];
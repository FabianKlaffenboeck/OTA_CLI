var NAVTREE =
[
  [ "Welcome to Kvaser CANlib SDK!", "index.html", [
    [ "Installation", "page_installing.html", "page_installing" ],
    [ "Kvaser Support", "page_support.html", null ],
    [ "License and Copyright", "page_license_and_copyright.html", null ],
    [ "Compiling and Compatibility", "page_user_guide_build.html", "page_user_guide_build" ],
    [ "Tutorials", "page_tutorial.html", "page_tutorial" ],
    [ "CAN bus API (CANlib)", "page_canlib.html", "page_canlib" ],
    [ "LIN bus API (LINlib)", "page_linlib.html", [
      [ "Description", "page_linlib.html#section_user_guide_lin_lib_1", null ],
      [ "Using the LIN Bus", "page_linlib.html#section_user_guide_lin_intro", null ],
      [ "LIN Frame Identifiers", "page_linlib.html#section_user_guide_lin_frame_identifiers", null ],
      [ "Where to go from here", "page_linlib.html#section_user_guide_lin_where_to_go_from_here", null ]
    ] ],
    [ "J1587 API (J1587lib)", "page_j1587.html", [
      [ "Description", "page_j1587.html#section_user_guide_j1587_1", null ],
      [ "Where to go from here", "page_j1587.html#section_user_guide_j1587_where_to_go_from_here", null ]
    ] ],
    [ "Database API (kvaDbLib)", "page_kvadblib.html", "page_kvadblib" ],
    [ "Converter API (kvlclib)", "page_kvlclib.html", "page_kvlclib" ],
    [ "Memorator API (kvmlib)", "page_kvmlib.html", [
      [ "Description", "page_kvmlib.html#section_user_guide_kvmlib_1", null ],
      [ "Naming convention", "page_kvmlib.html#section_user_guide_kvmlib_2", null ],
      [ "Build an application", "page_kvmlib.html#section_user_guide_kvmlib_3", null ],
      [ "Where to go from here", "page_kvmlib.html#section_user_guide_kvmlib_where_to_go_from_here", null ]
    ] ],
    [ "Memorator XML API (kvaMemoLibXML)", "page_kvamemolibxml.html", [
      [ "Description", "page_kvamemolibxml.html#section_user_guide_kvamemolibxml_1", null ],
      [ "Build an application", "page_kvamemolibxml.html#section_user_guide_kvamemolibxml_2", null ],
      [ "Where to go from here", "page_kvamemolibxml.html#section_user_guide_kvamemolibxml_where_to_go_from_here", null ]
    ] ],
    [ "Remote Device API (kvrlib)", "page_kvrlib.html", "page_kvrlib" ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"canlib_8h.html#aa35b3f04d717c654cec0a4f0468ebf84",
"canstat_8h.html#a52b5e5c71832b0bd3c6a5b1fd48583e7acd1c4c3a87dd24f0a43753ee4bfe7993",
"group___discovery.html#gad14788125816240a858213203df33fbf",
"group___obsolete.html#gad0f169d4007c3f56e4ca00a0c61010ce",
"group__kvadb__attributes.html#ga537998cc1fd0bc2e8f2960d75f53b672",
"group__kvadb__signals.html#gac592e48b7618d40d778698a5c21ed14d",
"group__kvm__rtc.html#ga0545d8d9c2782728d263ed67cbc0efac",
"kva_db_lib_8h.html#acb793e70d95b7daf6045c6dd9cc8792d",
"kvmlib_8h.html#a7d3cf80248d9011329b4b269f8b7d2c4",
"obsolete_8h.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';
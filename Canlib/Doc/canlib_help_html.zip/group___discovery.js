var group___discovery =
[
    [ "kvrDeviceGetServiceStatus", "group___discovery.html#gaf17a1ee475ab65e1773c2edf851e5aa8", null ],
    [ "kvrDeviceGetServiceStatusText", "group___discovery.html#ga0c8461e07e555a47293e700b71b79d76", null ],
    [ "kvrDiscoveryClearDevicesAtExit", "group___discovery.html#ga8fbbaf90689d4dee244edddd7bc14ee0", null ],
    [ "kvrDiscoveryClose", "group___discovery.html#ga787488cf05c964fbde96346c297e112a", null ],
    [ "kvrDiscoveryGetDefaultAddresses", "group___discovery.html#ga387fae851acdcf59aef62f16ac59b233", null ],
    [ "kvrDiscoveryGetResults", "group___discovery.html#ga0d0f19cb2e156c82f70f42fcf958da25", null ],
    [ "kvrDiscoveryOpen", "group___discovery.html#gaa27f34a126fd04d13e4e6745a11beb46", null ],
    [ "kvrDiscoverySetAddresses", "group___discovery.html#ga122ec5535fef74d035c727365686e886", null ],
    [ "kvrDiscoverySetEncryptionKey", "group___discovery.html#ga81a54e4b2a58ddbefb3ec13b8b149cc2", null ],
    [ "kvrDiscoverySetPassword", "group___discovery.html#ga8c938eed8a528b7c5ffbf9faa298a9a0", null ],
    [ "kvrDiscoveryStart", "group___discovery.html#gad14788125816240a858213203df33fbf", null ],
    [ "kvrDiscoveryStartEx", "group___discovery.html#ga1f2f51f06410c084419482faa3bac7df", null ],
    [ "kvrDiscoveryStoreDevices", "group___discovery.html#ga8517ee0d846a9a14ddf34f4c881e59dd", null ]
];
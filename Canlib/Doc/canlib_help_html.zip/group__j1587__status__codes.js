var group__j1587__status__codes =
[
    [ "J1587Status", "group__j1587__status__codes.html#gaf53b99d641e8f580bd6d82dddf25044e", [
      [ "j1587OK", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea61f76560f1b283987ec14a1d254bedf6", null ],
      [ "j1587ERR_NOMSG", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea0bf9a407af27b4622bac41d06506ce08", null ],
      [ "j1587ERR_NOTRUNNING", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea72264506a27e251c1f0d2c60d8e161ab", null ],
      [ "j1587ERR_RUNNING", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044eadc3b70428e7a42d2d25c65c05f62b07a", null ],
      [ "j1587ERR_NORMALONLY", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea6ca7cad03a285d25b2507c149b3481c2", null ],
      [ "j1587ERR_NODEONLY", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea2a87006063a0d35daf456791262de017", null ],
      [ "j1587ERR_PARAM", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044eaf183ce935e3bade3615f02a717b08fc8", null ],
      [ "j1587ERR_NOTFOUND", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044eadfb1500c01c1a3d8780860db14a7fe67", null ],
      [ "j1587ERR_NOMEM", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044eaf42cc4ee6b51df763ad0d8a1cc97ea90", null ],
      [ "j1587ERR_NOCHANNELS", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ead15388cb0f1cee8d6bf44ebdc4c1d16b", null ],
      [ "j1587ERR_TIMEOUT", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea37943b1490ca35c107ef2f42326c208f", null ],
      [ "j1587ERR_NOTINITIALIZED", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044eaea1628608ad78a6935250b7d111dee2a", null ],
      [ "j1587ERR_NOHANDLES", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea46d291797f09b533e859f9ce2de462e7", null ],
      [ "j1587ERR_INVHANDLE", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea5c5263d694cb6925ae5ab7517c1a0aff", null ],
      [ "j1587ERR_CANERROR", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea9f037a8a09fd557c8893b144ae182400", null ],
      [ "j1587ERR_ERRRESP", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea2a5e6c37a958005335aefab7d1338602", null ],
      [ "j1587ERR_WRONGRESP", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea2ee0e2e8e5d1047ee09c6c3cd17b6aff", null ],
      [ "j1587ERR_DRIVER", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea59ccb0b8385302b05ae8437c368139a0", null ],
      [ "j1587ERR_DRIVERFAILED", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044eaba134aee4fa5bfa8d22f19aa3883db43", null ],
      [ "j1587ERR_NOCARD", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea195f90860f7fef3b482f33bafbebfdb5", null ],
      [ "j1587ERR_LICENSE", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044eae242c3e6daecb06ae9fe7486742ae2c9", null ],
      [ "j1587ERR_INTERNAL", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea3842e531e590e00974e506a540237aaa", null ],
      [ "j1587ERR_NO_ACCESS", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea6b775f52dd36245e1a1b33571bbd5e3c", null ],
      [ "j1587ERR_VERSION", "group__j1587__status__codes.html#ggaf53b99d641e8f580bd6d82dddf25044ea715c4c02f8d57754804cb8b865dcaff6", null ]
    ] ]
];
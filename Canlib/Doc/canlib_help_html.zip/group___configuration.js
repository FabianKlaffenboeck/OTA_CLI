var group___configuration =
[
    [ "kvrConfigActiveProfileGet", "group___configuration.html#gaecaeec3f726a550a27adac439265c7e6", null ],
    [ "kvrConfigActiveProfileSet", "group___configuration.html#ga69ad84bcd16bda9ca3fedafff184d23d", null ],
    [ "kvrConfigClear", "group___configuration.html#ga6781ecbad4028f5222264769c5b383f1", null ],
    [ "kvrConfigClose", "group___configuration.html#ga9d7d88d28627b7719ce000cb4ad623a3", null ],
    [ "kvrConfigGet", "group___configuration.html#ga8af113cff1b393f2ddaab912fc868256", null ],
    [ "kvrConfigInfoGet", "group___configuration.html#gade6145c732f860bf9bfc18f399e8a15c", null ],
    [ "kvrConfigNoProfilesGet", "group___configuration.html#ga2e4d24d184684f7b3b2096bb7545fd66", null ],
    [ "kvrConfigOpen", "group___configuration.html#ga10377faa9fc90b8cdc8ee11fc03d460d", null ],
    [ "kvrConfigOpenEx", "group___configuration.html#gaf46f7657a04022315ea95c584e3b5ef5", null ],
    [ "kvrConfigSet", "group___configuration.html#ga15b6bd4dee1ff31964069f54d2918fd6", null ],
    [ "kvrConfigVerifyXml", "group___configuration.html#ga04cbfb06bbb9267e9347575a9dd3eaa0", null ]
];
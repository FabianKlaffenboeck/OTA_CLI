var group___time_domain_handling =
[
    [ "kvTimeDomainAddHandle", "group___time_domain_handling.html#ga7db84bcaf7a2163298e3b318748ccb41", null ],
    [ "kvTimeDomainCreate", "group___time_domain_handling.html#gaef2b34a7cd8ab01fc140aabe3a5f5539", null ],
    [ "kvTimeDomainDelete", "group___time_domain_handling.html#gaf42198d9685ffc7094fc4cd276ab1976", null ],
    [ "kvTimeDomainGetData", "group___time_domain_handling.html#gafab02cbe0c7fd8cfa65382d492d724b9", null ],
    [ "kvTimeDomainRemoveHandle", "group___time_domain_handling.html#ga71f7890c6b77e80de99a3c9416cacf24", null ],
    [ "kvTimeDomainResetTime", "group___time_domain_handling.html#gaf1857d6195e783c082b44a6e6cf9f745", null ]
];